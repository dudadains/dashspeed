# DashGen — Gerador de Dashboards com IA

Gere dashboards HTML profissionais em 1 clique a partir de qualquer dado de campanha.

---

## Deploy no Vercel (passo a passo)

### 1. Crie uma conta no GitHub
Acesse https://github.com e crie uma conta gratuita (se ainda não tiver).

### 2. Crie um repositório
- Clique em **"New repository"**
- Nome: `dashgen`
- Deixe como **Public**
- Clique em **"Create repository"**

### 3. Suba os arquivos
Arraste os arquivos desta pasta para o repositório:
```
dashgen/
├── api/
│   └── generate.js      ← backend (não mexa)
├── public/
│   └── index.html       ← frontend
├── vercel.json          ← configuração do Vercel
└── README.md
```

### 4. Crie uma conta no Vercel
Acesse https://vercel.com e faça login com o GitHub.

### 5. Importe o projeto
- Clique em **"Add New Project"**
- Selecione o repositório `dashgen`
- Clique em **"Deploy"**

### 6. Configure a API Key (IMPORTANTE)
Sem isso o gerador não funciona:

- No Vercel, vá em **Settings → Environment Variables**
- Clique em **"Add New"**
- Nome: `ANTHROPIC_API_KEY`
- Valor: sua chave da API (começa com `sk-ant-...`)
  - Pegue em: https://console.anthropic.com/settings/keys
- Clique em **"Save"**
- Vá em **Deployments → clique nos 3 pontinhos → Redeploy**

### 7. Pronto!
Seu link vai ser algo como: `https://dashgen-seutime.vercel.app`

---

## Como usar

1. Abra o link
2. Digite o nome do cliente
3. Cole os dados da campanha (qualquer formato) ou faça upload de CSV
4. Clique em **"Gerar Dashboard"**
5. Baixe o HTML e entregue pro cliente

---

## Custo estimado

- **Vercel**: gratuito para uso interno do time
- **Anthropic API**: ~R$ 0,10 a R$ 0,30 por dashboard gerado
  - Veja os preços em: https://www.anthropic.com/pricing

---

## Dúvidas?

Se aparecer erro "Failed to fetch", verifique se a variável `ANTHROPIC_API_KEY` foi configurada e se fez o redeploy após salvar.
