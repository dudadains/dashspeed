module.exports = async function handler(req, res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'POST, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type');

  if (req.method === 'OPTIONS') {
    return res.status(200).end();
  }

  if (req.method !== 'POST') {
    return res.status(405).json({ error: 'Method not allowed' });
  }

  if (!process.env.ANTHROPIC_API_KEY) {
    return res.status(500).json({
      error: 'ANTHROPIC_API_KEY não configurada no servidor. Adicione essa variável nas Environment Variables do projeto na Vercel.'
    });
  }

  const body = typeof req.body === 'string'
    ? safeJsonParse(req.body)
    : (req.body || {});

  const clientName = String(body.clientName || 'Cliente').trim() || 'Cliente';
  const rawData = String(body.rawData || '').trim();

  if (!rawData) {
    return res.status(400).json({ error: 'Dados ausentes. Envie o conteúdo da campanha em rawData.' });
  }

  const prompt = `Você é um especialista em análise de dados de marketing digital e criação de dashboards HTML.

Com base nos dados abaixo, crie um dashboard HTML completo, bonito e profissional para o cliente "${clientName}".

DADOS DA CAMPANHA:
${rawData}

INSTRUÇÕES OBRIGATÓRIAS:
- Responda APENAS com um arquivo HTML completo.
- O HTML DEVE começar com <!DOCTYPE html>.
- Não escreva explicações, comentários fora do HTML, markdown ou backticks.
- O arquivo deve ser autocontido.
- Pode usar Chart.js via CDN: https://cdnjs.cloudflare.com/ajax/libs/Chart.js/4.4.1/chart.umd.js
- Use layout moderno, profissional e responsivo.
- Fundo escuro (#0f0f0f ou similar).
- Inclua cards de métricas principais.
- Inclua gráficos úteis para comparação entre canais, campanhas ou períodos, quando possível.
- Inclua uma tabela de detalhamento por canal, quando houver dados suficientes.
- Calcule métricas derivadas quando houver dados: CTR, CPM, CPC e custo por venda/conversão.
- Mostre o nome do cliente "${clientName}" no cabeçalho.
- Mostre a data de geração do dashboard.
- Se alguns dados estiverem incompletos, monte o melhor dashboard possível com o que existir.
- Garanta HTML válido, com <html>, <head>, <body> e scripts necessários.`;

  try {
    const response = await fetch('https://api.anthropic.com/v1/messages', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'x-api-key': process.env.ANTHROPIC_API_KEY,
        'anthropic-version': '2023-06-01'
      },
      body: JSON.stringify({
        model: 'claude-sonnet-4-20250514',
        max_tokens: 8000,
        messages: [{ role: 'user', content: prompt }]
      })
    });

    const data = await response.json().catch(() => ({}));

    if (!response.ok) {
      return res.status(response.status).json({
        error: data?.error?.message || 'Erro na API da Anthropic.'
      });
    }

    if (!Array.isArray(data.content)) {
      return res.status(502).json({ error: 'Resposta inválida da API da Anthropic.' });
    }

    let html = data.content.map(block => block?.text || '').join('');
    html = sanitizeModelHtml(html);

    if (!html || !/^<!doctype html>/i.test(html)) {
      return res.status(502).json({
        error: 'A IA não retornou um HTML completo começando com <!DOCTYPE html>.'
      });
    }

    return res.status(200).json({ html });
  } catch (error) {
    return res.status(500).json({ error: error.message || 'Erro interno do servidor.' });
  }
};

function safeJsonParse(value) {
  try {
    return JSON.parse(value);
  } catch {
    return {};
  }
}

function sanitizeModelHtml(html) {
  return String(html || '')
    .replace(/```html\s*/gi, '')
    .replace(/```\s*/g, '')
    .trim();
}
