export default async function handler(req, res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'POST, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type');

  if (req.method === 'OPTIONS') return res.status(200).end();
  if (req.method !== 'POST') return res.status(405).json({ error: 'Method not allowed' });

  const { clientName, rawData } = req.body;

  if (!rawData) return res.status(400).json({ error: 'Dados ausentes' });

  const prompt = `Você é um especialista em análise de dados de marketing digital e criação de dashboards HTML.

Com base nos dados abaixo, crie um dashboard HTML completo, bonito e profissional para o cliente "${clientName || 'Cliente'}".

DADOS DA CAMPANHA:
${rawData}

INSTRUÇÕES:
- Crie um arquivo HTML COMPLETO e autocontido (tudo inline, sem arquivos externos exceto CDNs)
- Use Chart.js via CDN (https://cdnjs.cloudflare.com/ajax/libs/Chart.js/4.4.1/chart.umd.js) para gráficos
- Design moderno e profissional com fundo escuro (#0f0f0f ou similar)
- Inclua: cards de métricas principais, gráficos de barras/pizza para comparações, tabela de detalhamento por canal
- Calcule métricas derivadas: CTR (cliques/impressões*100), CPM (investimento/impressões*1000), CPC (investimento/cliques), custo por venda se houver
- Mostre o nome do cliente "${clientName}" no cabeçalho com logo placeholder
- Use cores vibrantes para os gráficos
- Mostre data de geração
- Responda APENAS com o código HTML completo, começando com <!DOCTYPE html>, sem explicações, sem markdown, sem backticks`;

  try {
    const response = await fetch('https://api.anthropic.com/v1/messages', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'x-api-key': process.env.ANTHROPIC_API_KEY,
        'anthropic-version': '2023-06-01'
      },
      body: JSON.stringify({
        model: 'claude-sonnet-4-20250514',
        max_tokens: 8000,
        messages: [{ role: 'user', content: prompt }]
      })
    });

    const data = await response.json();

    if (!response.ok) throw new Error(data.error?.message || 'Erro na API Anthropic');

    let html = data.content.map(b => b.text || '').join('');
    html = html.replace(/```html\n?/g, '').replace(/```\n?/g, '').trim();

    res.status(200).json({ html });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
}
